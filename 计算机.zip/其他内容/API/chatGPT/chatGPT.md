# chatGPT

<https://openai.com/api/pricing/>

| ​**LATEST MODEL** | ​**DESCRIPTION**                                                   | ​**MAX REQUEST** | ​**TRAINING DATA** |
| ----------------- | ------------------------------------------------------------------ | ---------------- | ------------------ |
| text-davinci-003  | 功能最强大的GPT-3模型。可以做任何其他模型可以做的任务，通常具有更高的质量，更长的输出和更好的指令遵循。还支持在文本中插入补全。 | 4,000 tokens     | Up to Jun 2021     |
| text-curie-001    | 非常有能力，但比达芬奇更快，成本更低。                                                | 2,048 tokens     | Up to Oct 2019     |
| text-babbage-001  | 能够直接完成任务，非常快，成本更低。                                                 | 2,048 tokens     | Up to Oct 2019     |
| text-ada-001      | 能够完成非常简单的任务，通常是GPT-3系列中速度最快的型号，成本最低。                               |                  |                    |
