# RFC

[RFC2612-http1.1](RFC2612-http1.1/RFC2612-http1.1.md "RFC2612-http1.1")
