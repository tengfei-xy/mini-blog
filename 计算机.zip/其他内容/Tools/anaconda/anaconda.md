# anaconda

下载安装脚本

```纯文本
https://repo.anaconda.com/archive/Anaconda3-2022.10-MacOSX-x86_64.sh
```

执行安装脚本

```纯文本
chmod +x Anaconda3-2022.10-MacOSX-x86_64.sh && ./Anaconda3-2022.10-MacOSX-x86_64.sh
```
