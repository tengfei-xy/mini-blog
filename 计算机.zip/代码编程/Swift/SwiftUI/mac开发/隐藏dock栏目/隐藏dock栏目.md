# 隐藏dock栏目

1.  查看项目.xcodeproj
2.  在info下添加添加一个配置项,**pplication is agent (UI Element)**,Value选择Yes
