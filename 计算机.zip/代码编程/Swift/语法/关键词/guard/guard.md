# guard

guard用在中断流程，而if-else用在流程选择
