# 从web下载文件

## 目录

-   [下载文件](#下载文件)

# 下载文件

```powershell
Invoke-WebRequest -uri $src -OutFile $des
```
