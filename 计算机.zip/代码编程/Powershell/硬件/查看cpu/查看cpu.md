# 查看cpu

```powershell
Get-WmiObject win32_processor
```
