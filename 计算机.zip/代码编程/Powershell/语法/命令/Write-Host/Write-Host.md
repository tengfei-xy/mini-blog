# Write-Host

打印233
`Write-Host 233`

打印数组变量
`Write-Host  $args[0]`

打印变量和字符串

`Write-Host 主机名:($pc),-开机时间:($pcline.TurnOnTime),-关机时间:($pcline.TurnOffTime)`
