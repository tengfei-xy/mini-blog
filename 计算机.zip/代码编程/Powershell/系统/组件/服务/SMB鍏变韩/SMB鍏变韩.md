# SMB鍏变韩

```纯文本
Get-SmbShare -session (New-CimSession -ComputerName adserver)
```
