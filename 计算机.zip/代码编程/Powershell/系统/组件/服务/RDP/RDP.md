# RDP

```powershell
Get-Service -name TermService | Restart-Service -force
```
