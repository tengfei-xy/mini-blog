# if

```纯文本
EQU - 等于 
NEQ - 不等于 
LSS - 小于 
LEQ - 小于或等于 
GTR - 大于 
GEQ - 大于或等于
```

if

```纯文本
if "%errorlevel%" EQU "1" (
    echo 程序执行错误
)
```
