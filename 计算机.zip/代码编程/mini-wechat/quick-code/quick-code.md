# quick-code

[data](data/data.md "data")

[radio](radio/radio.md "radio")

[table](table/table.md "table")

[修改标题](修改标题/修改标题.md "修改标题")

[全局变量](全局变量/全局变量.md "全局变量")
