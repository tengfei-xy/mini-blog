# radio

```纯文本
          <view class="line-title"></view>
					<radio-group class="line-content">
            <label style="display:flex;flex-direction: column;">
              <radio></radio>
            </label>
          </radio-group>
```
