# data

## 目录

-   [js](#js)
-   [wxml](#wxml)

## js

```纯文本
toCycle: function(e) {
	console.log(e.currentTarget.dataset.siska)
}
```

## wxml

```纯文本
    <view class="tr" bindtap="toCycle"  data-siska="患者C">
```
