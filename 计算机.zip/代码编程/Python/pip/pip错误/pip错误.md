# pip错误

源问题

```纯文本
Q:
ERROR: Could not find a version that satisfies the requirement request (from versions: none)
ERROR: No matching distribution found for request

A:
pip3 install xxxxxx  -i http://pypi.douban.com/simple/ --trusted-host pypi.douban.com
```
