# go-env

sudo /usr/local/go/bin/go env -w GOPROXY=[https://goproxy.cn](https://goproxy.cn "https://goproxy.cn")

sudo /usr/local/go/bin/go env -w GOPROXY=192.168.2.207:41091

sudo go env -w GO111MODULE=on
