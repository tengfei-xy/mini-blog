# go-mod

replace print => ../print
