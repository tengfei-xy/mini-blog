# go-test

## 目录

-   [go test 规则](#go-test-规则)

# go test 规则

文件名是\*\_test.go
函数名是TestXxx或Test\_xxx
