# json转结构体

<https://tooltt.com/json2go/>
