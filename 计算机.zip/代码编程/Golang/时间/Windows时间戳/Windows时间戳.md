# Windows时间戳

导入包

```golang
import ("encoding/binary")
```

十六进制大端字节转int64

```golang
binary.LittleEndian.Uint64(erWriteTime)
```
