# node.js安装

<http://nodejs.cn/download/>

```纯文本
wget https://npmmirror.com/mirrors/node/v16.15.0/node-v16.15.0-linux-x64.tar.xz
```

```纯文本
wget https://npmmirror.com/mirrors/node/v18.12.1/node-v18.12.1-linux-x64.tar.xz
```

```纯文本
wget https://nodejs.org/dist/v18.15.0/node-v18.15.0-linux-x64.tar.xz
```
