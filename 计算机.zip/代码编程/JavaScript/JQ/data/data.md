# data

## 目录

-   [设置](#设置)

## 设置

`$.data( element, key, value )`

```javascript
jQuery.data( div, "test", {
    first: 16,
    last: "pizza!"
  });
```
