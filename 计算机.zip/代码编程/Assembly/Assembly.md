# Assembly

[BIOS中断](BIOS中断/BIOS中断.md "BIOS中断")

[寄存器](寄存器/寄存器.md "寄存器")

[指令](指令/指令.md "指令")

[栈](栈/栈.md "栈")

[NASM编译器](NASM编译器/NASM编译器.md "NASM编译器")

[汇编语法AT\&T](汇编语法AT\&T/汇编语法AT\&T.md "汇编语法AT\&T")

[汇编语法Intel](汇编语法Intel/汇编语法Intel.md "汇编语法Intel")
