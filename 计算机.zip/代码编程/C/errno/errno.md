# errno

定义

```纯文本
#include <errno.h>
```

具体定义参考

[进程返回值](../../OS/Linux/应用/进程/返回值.md "进程返回值")
