# MinGW（gcc\_for\_windows）

下载地址

```bash
http://sourceforge.net/projects/mingw/files/
```
