# windows

[注册表](注册表/注册表.md "注册表")

[GetLastError返回值](GetLastError返回值/GetLastError返回值.md "GetLastError返回值")

[MinGW（gcc\_for\_windows）](MinGW（gcc_for_windows）/MinGW（gcc_for_windows）.md "MinGW（gcc_for_windows）")
