# shell

[语法](语法/语法.md "语法")

[命令](命令/命令.md "命令")

[高级写法](高级写法/高级写法.md "高级写法")

[正则表达式](正则表达式/正则表达式.md "正则表达式")

[bash](bash/bash.md "bash")

[zsh](zsh/zsh.md "zsh")

[PATH](PATH/PATH.md "PATH")
