# PATH

```纯文本
PATH=/usr/local/sbin:/usr/local/bin:/usr/sbin:/usr/bin
export PATH=$PATH
```
