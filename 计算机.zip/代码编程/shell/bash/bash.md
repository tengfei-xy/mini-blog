# bash

[bash修改提示符](bash修改提示符/bash修改提示符.md "bash修改提示符")

[bind](bind/bind.md "bind")

[ctrl系列快捷键](ctrl系列快捷键/ctrl系列快捷键.md "ctrl系列快捷键")

[参考手册](参考手册/参考手册.md "参考手册")
