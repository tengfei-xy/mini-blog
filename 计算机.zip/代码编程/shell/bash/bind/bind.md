# bind

查看监听

```纯文本
bind -p
```

设定监听ctrl+L能执行echo \$PWD命令

```纯文本
bind -x '"\C-l":echo $PWD'
```
