# bash修改提示符

```纯文本
export PS1="\e[0;31m\u@\h \e[0;33m\w \$ \e[m"
```
