# zsh

[oh-my-ZSH](oh-my-ZSH/oh-my-ZSH.md "oh-my-ZSH")

[问题](问题/问题.md "问题")
