# php-fpm.conf

```纯文本
;fpm 监听地址
listen:0.0.0.0:9000
; 资源目录
chdir = /usr/local/php/www/html
```
