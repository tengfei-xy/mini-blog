# PHP

[安装](安装/安装.md "安装")

[php-fpm.conf](php-fpm.conf/php-fpm.conf.md "php-fpm.conf")

[绝对注意事项](绝对注意事项/绝对注意事项.md "绝对注意事项")
