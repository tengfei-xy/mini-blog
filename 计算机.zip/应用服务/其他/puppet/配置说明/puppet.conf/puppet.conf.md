# puppet.conf

根据不同的部分，打印、设置、删除属性的值
puppet config \[print|set|delete] \[setting\_name] \[setting\_value] —-section \[main(default)|master|agent|user]

puppet.conf文件说明链接:
[https://puppet.com/docs/puppet/6.10/configuration.html#configuration-settings](https://puppet.com/docs/puppet/6.10/configuration.html#configuration-settings "https://puppet.com/docs/puppet/6.10/configuration.html#configuration-settings")
