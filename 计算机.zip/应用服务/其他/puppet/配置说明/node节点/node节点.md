# node节点

## 目录

-   [node 节点](#node-节点)

# node 节点

单节点
node 'www1.example.com’{}

正则表达式节点
node /^(one|two).example.com\$/ {}

默认节点
node default {}
