# facter类型

Core facts, which are built into Facter and are common to almost all systems.
核心事实，这是建立在 Facter 和几乎所有系统的共同点。

Custom facts, which run Ruby code to produce a value.
定制事实，它运行 Ruby 代码生成一个值。

External facts, which return values from pre-defined static data, or the result of an executable script or program
外部事实，从预定义的静态数据或可执行脚本或程序的结果返回值。
