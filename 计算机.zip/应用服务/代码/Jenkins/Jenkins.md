# Jenkins

[gitlab触发构建](gitlab触发构建/gitlab触发构建.md "gitlab触发构建")

[安装](安装/安装.md "安装")

[查看版本](查看版本/查看版本.md "查看版本")
