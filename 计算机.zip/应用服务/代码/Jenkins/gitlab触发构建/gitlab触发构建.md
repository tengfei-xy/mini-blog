# gitlab触发构建

下载gitlab插件，从插件管理中安装，如果没有，直接下载插件文件

```纯文本
https://updates.jenkins.io/download/plugins/gitlab-plugin/1.7.14/gitlab-plugin.hpi
```

在gitlab中“settings-integrations”
